#!/usr/bin/env bash
# Installs awesome-ds-verify globally for Claude Code and Codex.
#   Claude Code  skill   ~/.claude/skills/awesome-ds-verify      (real copy)
#                command ~/.claude/commands/verify-ds.md         → /verify-ds
#   Codex        skill   ~/.agents/skills/awesome-ds-verify      (symlink → the copy above; Codex follows symlinks)
#                        invoke with  $awesome-ds-verify
#                prompt  ~/.codex/prompts/verify-ds.md           → /prompts:verify-ds
#                        (custom prompts are deprecated in Codex but still load; the skill is the durable path)
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CC_SKILL="$HOME/.claude/skills/awesome-ds-verify"
CODEX_SKILL="$HOME/.agents/skills/awesome-ds-verify"

mkdir -p "$HOME/.claude/skills" "$HOME/.claude/commands" "$HOME/.agents/skills" "$HOME/.codex/prompts"
rm -rf "$CC_SKILL"
cp -R "$SRC/awesome-ds-verify" "$CC_SKILL"
chmod +x "$CC_SKILL/scripts/"*.mjs
if [ -e "$CODEX_SKILL" ] || [ -L "$CODEX_SKILL" ]; then rm -rf "$CODEX_SKILL"; fi
ln -s "$CC_SKILL" "$CODEX_SKILL"
cp "$SRC/commands/claude-verify-ds.md" "$HOME/.claude/commands/verify-ds.md"
cp "$SRC/commands/codex-verify-ds.md"  "$HOME/.codex/prompts/verify-ds.md"

echo "installed:"
echo "  $CC_SKILL"
echo "  $CODEX_SKILL -> $CC_SKILL"
echo "  $HOME/.claude/commands/verify-ds.md"
echo "  $HOME/.codex/prompts/verify-ds.md"
echo
echo "smoke test:"
node "$CC_SKILL/scripts/verify-ds.mjs" --list | head -3
echo "restart Claude Code / Codex, then:  /verify-ds full /   (CC)   ·   \$awesome-ds-verify   (Codex)"
